bash restart_services.sh
