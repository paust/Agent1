java -javaagent:../ParameterTrackingAgent/ParameterTrackingAgent.jar=Fib.fib -Dtransformer-type=low -cp bin Fib 10
