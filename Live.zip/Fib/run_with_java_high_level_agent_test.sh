java -javaagent:../ParameterTrackingAgent/ParameterTrackingAgent.jar=Fib\$Person.create -Dtransformer-type=high -cp bin Fib 10
