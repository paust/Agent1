java -javaagent:../ParameterTrackingAgent/ParameterTrackingAgent.jar=Fib.fib -Dtransformer-type=high -cp bin Fib 10
