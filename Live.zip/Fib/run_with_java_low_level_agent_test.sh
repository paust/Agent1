java -javaagent:../ParameterTrackingAgent/ParameterTrackingAgent.jar=Fib\$Person.create -Dtransformer-type=low -cp bin Fib 10
