gcc -g -O3 -std=c99 -fPIC -shared -I/usr/lib/jvm/java-8-openjdk-amd64/include/ -I/usr/lib/jvm/java-8-openjdk-amd64/include/linux -o parameter_tracking_agent.so parameter_tracking_agent.c
